const mongoose = require("mongoose");

const postSchema = new mongoose.Schema({
    userid: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Users",                         
        required: true
    },
    title: {
        type: String,
        unique: true,     
        required: true
    },
    body: {
        type: String,
        required: true
    }
});


module.exports = mongoose.model("Posts", postSchema);


